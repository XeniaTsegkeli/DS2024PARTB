package com.example.ds2024part2;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ds2024part2.R;

public class SearchActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_screen); // Set the layout you created
    }
}
